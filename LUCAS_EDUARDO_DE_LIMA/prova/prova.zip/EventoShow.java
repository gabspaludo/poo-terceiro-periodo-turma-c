package prova;

public class EventoShow {

    public EventoShow(String nomeShow, String localShow) {
        
    }

    public String getNome() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getNome'");
    }
    
}
